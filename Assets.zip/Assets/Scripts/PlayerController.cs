using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Rigidbody rbplayer;
    public ParticleSystem explosion;
    public ParticleSystem dirt;
    public AudioClip jump;
    public AudioClip crash;
    private AudioSource playeraudio;
    public float jumpforce = 10f;
    public float GravityModifier;
    public bool Isonground = true;
    public bool gameover;
    public Animator objectanime;
    // Start is called before the first frame update
    void Start()
    {
        rbplayer = GetComponent<Rigidbody>();
        Physics.gravity *= GravityModifier;
        objectanime=GetComponent<Animator>();
        playeraudio= GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Space) && Isonground && !gameover )
        {
            rbplayer.AddForce(Vector3.up * jumpforce, ForceMode.Impulse);
            Isonground= false;
            objectanime.SetTrigger("Jump_trig");
            dirt.Stop();
            playeraudio.PlayOneShot(jump,1.0f);
        }
        
    }
    public void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            Isonground = true;
            dirt.Play();
        }
        else if (collision.gameObject.CompareTag("Obstacle"))
        {
            Debug.Log("Game over");
            gameover = true;
            objectanime.SetBool("Death_b", true);
            objectanime.SetInteger("DeathType_int", 1);
            explosion.Play();
            dirt.Stop();
            playeraudio.PlayOneShot(crash,1.0f);
        }
    
    }
}
