using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawnmanager : MonoBehaviour
{
    public GameObject obstaclePrefeb;
    private Vector3 spawnpos = new Vector3(25,0,0);
    private float startdelay = 2;
    private float enddelay = 2;
    public PlayerController playercontscript;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("spawnObstacle",startdelay,enddelay);
        playercontscript = GameObject.Find("Player").GetComponent<PlayerController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void spawnObstacle()
    {
        if (playercontscript.gameover == false)
        {
            Instantiate(obstaclePrefeb, spawnpos, obstaclePrefeb.transform.rotation);
        }
    }
}
